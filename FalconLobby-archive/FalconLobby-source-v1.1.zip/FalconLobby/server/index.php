<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Frameset//EN"
   "http://www.w3.org/TR/html4/frameset.dtd">
<html>
<head>
   <title>FalconLobby</title>
</head>

<frameset cols="25%,75%" bordercolor="#E8E8EA" border=5>
   <frame src="left.php" name="left">
   <frame src="home.php" name="content">
</frameset>

</html>
