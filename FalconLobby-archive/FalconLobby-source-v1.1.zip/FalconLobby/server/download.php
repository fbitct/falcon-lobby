<?
require_once("header.php");
?>

<h1>Download Info</h1>

<p>
To use FalconLobby, follow the below instructions
</p>

<ul>
<li>Download the latest FalconLobby client software from the
<a href="http://www.lead-pursuit.com/downloads.htm" target="_blank">Lead Pursuit Downloads Page</a>
<li>Run the downloaded installer file
<li>Once installed, FalconLobby will automatically run when you logon and will create the below tray icon<br>
<p align="center"><img src="images/trayicon.gif"></p>
<li>By default, FalconLobby will automatically download the list of active games every so often and import
this list into the Falcon &quot;phone book&quot; (the list of game servers shown on the Multiplayer/Internet screen).
With FalconLobby running the the background, you should always have an up to date list of active games in the 
Falcon phone book
<li>You can also visit this site to view the list of active games and chat with other pilots using the provided
chat room
<li>Right-clicking on the tray icon will provide a menu which will allow you to access the included help file
and customize the behavior of FalconLobby if desired
<li>If you will be hosting your own game server and would like your game server to show up in the list of active
games, right-click the tray icon and select "Publish My Game Server..." and then follow the instructions
<li>For more information on how to use FalconLobby, please see the included help file (right-click on the tray
icon and select "Help...")
</ul>

<?
require_once("footer.php");
?>
