<?
require_once("header.php");
?>

<h1>Links</h1>

<ul>
<li><a target="_blank" href="http://www.lead-pursuit.com/links.htm">Lead Pursuit Links Page</a>
</ul>

<h3>Discussion Forums</h3>
<ul>
<li><a target="_blank" href="http://www.f4hq.com/forums/index.php?s=bd8cdbdc168fe807d746b803e42684a6&showforum=2">Falcon 4.0 HeadQuarters</a>
<li><a target="_blank" href="http://forums.frugalsworld.com/vbb/forumdisplay.php?f=73">Frugal's World of Simulation</a>
<li><a target="_blank" href="http://www.simhq.com/simhq3/sims/boards/bbs/ultimatebb.php?ubb=forum;f=140">SimHQ</a>
</ul>

<h3>Multiplayer Websites</h3>
<ul>
<li><a target="_blank" href="http://www.multiviperforums.com/phpBB2/index.php">Multivipers</a>
<li><a target="_blank" href="http://thatshayne.com/HCS/Forum/index.php">Hardcore Sims</a>
</ul>

<h3>Gear</h3>
<ul>
<li><a target="_blank" href="http://www.saitek.com/">Saitek</a>
<li><a target="_blank" href="http://www.chproducts.com/">CH Products</a>
<li><a target="_blank" href="http://www.naturalpoint.com/">NaturalPoint TrackIR</a>
</ul>

<?
require_once("footer.php");
?>
