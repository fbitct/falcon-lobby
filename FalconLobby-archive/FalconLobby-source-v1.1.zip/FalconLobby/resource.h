//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by FalconLobby.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_FALCONLOBBY_DIALOG          102
#define IDP_SOCKETS_INIT_FAILED         103
#define IDR_HTML_HTMLVIEWER             104
#define IDR_HTML_REGISTERGAMESERVER     105
#define IDR_MAINFRAME                   128
#define IDI_TRAY_ICON                   129
#define IDR_POPUP_MENU                  130
#define IDI_TRAY_ICON_LIT               130
#define IDD_REGISTERGAMESERVER          134
#define IDD_SERVER                      135
#define IDD_SERVER_PUBLICINFO           136
#define IDC_TITLE                       1002
#define IDC_CREDITS                     1003
#define IDC_ABICON                      1004
#define IDC_REGISTER                    1005
#define IDC_CANCEL                      1006
#define IDC_NAME                        1007
#define IDC_TOKEN                       1008
#define IDC_AUTOPUB                     1009
#define IDC_BACKUPWARNING               1010
#define IDC_SETPUBLICINFO               1011
#define IDC_REGISTERNEWGAMESERVER       1012
#define IDC_DESC                        1013
#define IDC_HOMEPAGE                    1014
#define IDC_VOICECOMM                   1015
#define IDC_OK                          1016
#define IDC_DOWN                        1018
#define IDC_BUTTON1                     1019
#define ID_TRAY_ABOUT                   32774
#define ID_TRAY_HELP                    32775
#define ID_TRAY_EXIT                    32776
#define ID_TRAY_EDITSETTINGSFILE        32777
#define ID_TRAY_PUBLISHMYGAMESERVER     32778
#define ID_TRAY_VIEWACTIVEGAMESERVERS   32780
#define ID_TRAY_AUTORETRIEVE            32781
#define ID_TRAY_MANUALRETRIEVE          32783
#define ID_TRAY_FALCONLOBBYHOMEPAGE     32784

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        137
#define _APS_NEXT_COMMAND_VALUE         32785
#define _APS_NEXT_CONTROL_VALUE         1020
#define _APS_NEXT_SYMED_VALUE           106
#endif
#endif
