#ifndef MUTEX_H
#define MUTEX_H

#include <string>

/**
 * mutex wrapper
 */
class Mutex
{
public:
	Mutex(const char * name);
	~Mutex();

protected:
	HANDLE m_hMutex;
	std::string m_name;
};

#endif
