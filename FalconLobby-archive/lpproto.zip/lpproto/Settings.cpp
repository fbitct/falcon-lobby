#include "stdafx.h"
#include "Settings.h"
#include "INIFile.h"

#define SETTINGS_FILE "settings.ini"

Settings::Settings()
{
   inifile = INIFile::getINIFile(SETTINGS_FILE);
}

Settings::~Settings()
{
}

std::string Settings::getSettingsString(std::string section, std::string name)
{
   return inifile->getString(section,name);
}

int Settings::getSettingsInt(std::string section, std::string name)
{
   return inifile->getInt(section,name);
}

void Settings::setSettingsString(std::string section, std::string name, std::string val)
{
   inifile->setString(section,name,val);
}

