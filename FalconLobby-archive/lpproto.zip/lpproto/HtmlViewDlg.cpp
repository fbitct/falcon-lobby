// HtmlViewDlg.cpp : implementation file
//

#include "stdafx.h"
#include "lpproto.h"
#include "HtmlViewDlg.h"


// CHtmlViewDlg dialog

IMPLEMENT_DYNCREATE(CHtmlViewDlg, CDHtmlDialog)

CHtmlViewDlg::CHtmlViewDlg(CWnd* pParent /*=NULL*/)
	: CDHtmlDialog(CHtmlViewDlg::IDD, CHtmlViewDlg::IDH, pParent)
{
}

CHtmlViewDlg::~CHtmlViewDlg()
{
}

void CHtmlViewDlg::setUrl(LPCTSTR url)
{
   m_url = url;
}

void CHtmlViewDlg::DoDataExchange(CDataExchange* pDX)
{
	CDHtmlDialog::DoDataExchange(pDX);
}

BOOL CHtmlViewDlg::OnInitDialog()
{
	CDHtmlDialog::OnInitDialog();
   Navigate(m_url);
	return TRUE;  // return TRUE  unless you set the focus to a control
}

BEGIN_MESSAGE_MAP(CHtmlViewDlg, CDHtmlDialog)
END_MESSAGE_MAP()

BEGIN_DHTML_EVENT_MAP(CHtmlViewDlg)
	DHTML_EVENT_ONCLICK(_T("ButtonOK"), OnButtonOK)
	DHTML_EVENT_ONCLICK(_T("ButtonCancel"), OnButtonCancel)
END_DHTML_EVENT_MAP()



// CHtmlViewDlg message handlers

HRESULT CHtmlViewDlg::OnButtonOK(IHTMLElement* /*pElement*/)
{
	OnOK();
	return S_OK;  // return TRUE  unless you set the focus to a control
}

HRESULT CHtmlViewDlg::OnButtonCancel(IHTMLElement* /*pElement*/)
{
	OnCancel();
	return S_OK;  // return TRUE  unless you set the focus to a control
}
