// lpprotoDlg.cpp : implementation file
//

#include "stdafx.h"
#include "lpproto.h"
#include "lpprotoDlg.h"
#include ".\lpprotodlg.h"

#include "PhoneBook.h"
#include "NetUtils.h"

#include "htmlviewdlg.h"

#include "INIFile.h"

#include <sstream>
using namespace std;

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

using namespace std;

// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()


// ClpprotoDlg dialog



ClpprotoDlg::ClpprotoDlg(CWnd* pParent /*=NULL*/)
	: CDialog(ClpprotoDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void ClpprotoDlg::DoDataExchange(CDataExchange* pDX)
{
   CDialog::DoDataExchange(pDX);
   DDX_Control(pDX, IDC_EDIT1, m_ctlName);
   DDX_Control(pDX, IDC_EDIT2, m_ctlToken);
   DDX_Control(pDX, IDC_TITLE_PUBLISH, m_ctlTitlePublish);
   DDX_Control(pDX, IDC_SERVER_LIST, m_ctlServerList);
   DDX_Control(pDX, IDC_TITLE_FETCH, m_ctlTitleFetch);
   DDX_Control(pDX, IDC_AUTODETECT, m_ctlAutoDetect);
   DDX_Control(pDX, IDC_UP, m_ctlUp);
   DDX_Control(pDX, IDC_DOWN, m_ctlDown);
   DDX_Control(pDX, IDC_HOME_PAGE, m_ctlHomePage);
   DDX_Control(pDX, IDC_VOICE_COMMS, m_ctlVoiceComms);
   DDX_Control(pDX, IDC_GAME_SERVER_DESC, m_ctlDesc);
}

BEGIN_MESSAGE_MAP(ClpprotoDlg, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
//   ON_BN_CLICKED(IDC_BUTTON1, OnBnClickedButton1)
ON_BN_CLICKED(IDC_REGISTER, OnBnClickedRegister)
ON_BN_CLICKED(IDC_UP, OnBnClickedUp)
ON_BN_CLICKED(IDC_DOWN, OnBnClickedDown)
ON_BN_CLICKED(IDC_FETCH_SERVERS, OnBnClickedFetchServers)
ON_BN_CLICKED(IDC_AUTODETECT, OnBnClickedAutodetect)
ON_WM_TIMER()
ON_BN_CLICKED(IDC_VIEW_STATUS, OnBnClickedViewStatus)
ON_BN_CLICKED(IDC_SUBMIT_PUBLIC_INFO, OnBnClickedSubmitPublicInfo)
END_MESSAGE_MAP()


// ClpprotoDlg message handlers

UINT threadProc(LPVOID lpParm);

BOOL ClpprotoDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// TODO: Add extra initialization here
	LOGFONT lf;
   GetFont()->GetLogFont(&lf);
   lf.lfWeight = FW_BOLD;
   m_boldFont.CreateFontIndirect(&lf);
   m_ctlTitlePublish.SetFont(&m_boldFont);
   m_ctlTitleFetch.SetFont(&m_boldFont);

   m_ctlToken.SetWindowText(getSettingsString("gameserver","token").c_str());
   m_ctlName.SetWindowText(getSettingsString("gameserver","name").c_str());

   SetTimer(101,5000,0);

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void ClpprotoDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void ClpprotoDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR ClpprotoDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}


void ClpprotoDlg::OnBnClickedRegister()
{
   CString cs;
   m_ctlName.GetWindowText(cs);
   string name(cs);

   string token;
   string error;
   if (m_client.registerNewGame(name,token,error))
   {
      m_ctlToken.SetWindowText(token.c_str());
      setSettingsString("gameserver","token",token);
      setSettingsString("gameserver","name",name);
      AfxMessageBox("Registration Succeeded!");
   }
   else
   {
      cs.Format("Registration Failed: %s", error.c_str());
      AfxMessageBox(cs);
   }
}


void ClpprotoDlg::OnBnClickedUp()
{
   CString cs;
   m_ctlToken.GetWindowText(cs);
   string token(cs);

   string error;
   if (m_client.setGameState(token,true,error))
   {
      AfxMessageBox("Set Game State Succeeded!");
   }
   else
   {
      cs.Format("Failed to Set Game State: %s", error.c_str());
      AfxMessageBox(cs);
   }
}

void ClpprotoDlg::OnBnClickedDown()
{
   CString cs;
   m_ctlToken.GetWindowText(cs);
   string token(cs);

   string error;
   if (m_client.setGameState(token,false,error))
   {
      AfxMessageBox("Set Game State Succeeded!");
   }
   else
   {
      cs.Format("Failed to Set Game State: %s", error.c_str());
      AfxMessageBox(cs);
   }
}

void ClpprotoDlg::OnBnClickedFetchServers()
{
   CString cs;

   vector<Client::Game> activeGames;
   string error;

   PhoneBook pb;
   bool writePhoneBook = (AfxMessageBox("Overwrite local comHistory.dat file with results?",MB_YESNO) == IDYES);
   if (writePhoneBook)
   {
      if (!pb.exists())
      {
         AfxMessageBox("comHistory.dat file doesn't exist; Falcon might not be installed");
         writePhoneBook = false;
      }
   }

   if (m_client.getActiveGames(activeGames,error))
   {
      m_ctlServerList.ResetContent();

      if (writePhoneBook)
      {
         pb.makeBackupCopy();
         pb.clear();
      }

      vector<Client::Game>::iterator i;
      for (i = activeGames.begin(); i != activeGames.end(); ++i)
      {
         cs.Format("name:%s, ip:%s, uptime:%d",
            i->game_name.c_str(),
            i->game_ip.c_str(),
            i->game_uptime);
         m_ctlServerList.AddString(cs);

         if (writePhoneBook)
         {
            pb.addEntry(i->game_name,i->game_ip);
         }
      }

      if (writePhoneBook)
      {
         AfxMessageBox("local phonebook overwritten with list of active games; backup copy was made as comHistory.dat.orig");
      }
   }
   else
   {
      cs.Format("Failed to Fetch the list of Active Games: %s", error.c_str());
      AfxMessageBox(cs);
   }
}

void ClpprotoDlg::OnBnClickedAutodetect()
{
   bool flag = (m_ctlAutoDetect.GetCheck() == BST_CHECKED);

   m_ctlUp.EnableWindow(!flag);
   m_ctlDown.EnableWindow(!flag);
}

void ClpprotoDlg::OnTimer(UINT nIDEvent)
{
   if ((nIDEvent == 101) &&
       (m_ctlAutoDetect.GetCheck() == BST_CHECKED))
   {
      NetUtils nu;
      bool serverUp = nu.portInUse(getSettingsInt("Falcon","port"),SOCK_DGRAM);

      static bool updatedState = false;
      static bool prevState = false;

      if ((!updatedState) ||
          (serverUp != prevState))
      {
         updatedState = setServerState(serverUp);
         if (updatedState)
         {
            prevState = serverUp;
         }
      }
   }
}

bool ClpprotoDlg::setServerState(bool state)
{
   bool result = false;
   CString cs;
   m_ctlToken.GetWindowText(cs);
   string token(cs);

   string error;
   if (m_client.setGameState(token,state,error))
   {
      result = true;
   }

   return result;
}


void ClpprotoDlg::OnBnClickedViewStatus()
{
   CHtmlViewDlg d;

   stringstream str;
   str << "http://"
       << getSettingsString("gameserver_registry","host")
       << ":" << getSettingsInt("gameserver_registry","port")
       << getSettingsString("gameserver_registry","games_path");

   d.setUrl(str.str().c_str());
   d.DoModal();
}

void ClpprotoDlg::OnBnClickedSubmitPublicInfo()
{
   CString cs;

   m_ctlToken.GetWindowText(cs);
   string token(cs);
   m_ctlHomePage.GetWindowText(cs);
   string homePage(cs);
   m_ctlVoiceComms.GetWindowText(cs);
   string voiceComms(cs);
   m_ctlDesc.GetWindowText(cs);
   string desc(cs);

   string error;
   if (m_client.setGameInfo(token,homePage,voiceComms,desc,error))
   {
      AfxMessageBox("Game Public Info successfully set!");
   }
   else
   {
      cs.Format("Failed to set game public info: %s", error.c_str());
      AfxMessageBox(cs);
   }
}
