#ifndef PHONEBOOK_H
#define PHONEBOOK_H

#include "Settings.h"

#include <string>

/** 
 * provides the ability to write a new Falcon comHistory.dat phone book file
 */
class PhoneBook: public Settings
{
public:
   PhoneBook();
   virtual ~PhoneBook();

   /**
    * returns whether or not the phone book file exists
    */
   bool exists();

   /**
    * makes a backup copy of the phonebook file
    */
   void makeBackupCopy();

   /**
    * clears out the current phone book
    */
   void clear();

   /**
    * appends the specified info to the phonebook as a new entry
    */
   void addEntry(std::string game_name, std::string game_ip);

private:
   
   /**
    * determines path to the phone book file
    */
   bool getPhoneBookFile(std::string & phoneBookFile);
};

#endif
