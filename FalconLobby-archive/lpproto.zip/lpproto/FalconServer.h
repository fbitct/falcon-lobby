#ifndef FALCONSERVER_H
#define FALCONSERVER_H

class FalconServer
{
public:
   FalconServer();
   virtual ~FalconServer();
};

#endif
