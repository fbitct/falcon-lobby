#include "stdafx.h"
#include "Client.h"

#include <sstream>
using namespace std;

Client::Client()
{
}

Client::~Client()
{
}

bool Client::registerNewGame(string gameName, string & gameToken, string & error)
{
   bool result = false;
   gameToken = "";
   error = "";

   vector< pair<string,string> > formFields;
   formFields.push_back(make_pair("method","newgame"));
   formFields.push_back(make_pair("game_name",gameName));

   string response;
   if (httpClient.post(getRequestURL(),formFields,response,error))
   {
      vector<string> results;
      if (parseServerResponse(response,results,error))
      {
         gameToken = results.front();
         result = true;
      }
   }

   return result;
}

bool Client::setGameState(std::string gameToken, bool isUp, std::string & error)
{
   bool result = false;
   error = "";

   vector< pair<string,string> > formFields;
   formFields.push_back(make_pair("method","setgamestate"));
   formFields.push_back(make_pair("game_token",gameToken));
   formFields.push_back(make_pair("game_state",(isUp ? "up" : "down")));

   string response;
   if (httpClient.post(getRequestURL(),formFields,response,error))
   {
      vector<string> results;
      if (parseServerResponse(response,results,error))
      {
         result = true;
      }
   }

   return result;
}

bool Client::setGameInfo(std::string gameToken, std::string gameHomePage, std::string gameVoiceComm, std::string gameDesc, std::string & error)
{
   bool result = false;
   error = "";

   vector< pair<string,string> > formFields;
   formFields.push_back(make_pair("method","setgameinfo"));
   formFields.push_back(make_pair("game_token",gameToken));
   formFields.push_back(make_pair("game_homepage",gameHomePage));
   formFields.push_back(make_pair("game_voicecomm",gameVoiceComm));
   formFields.push_back(make_pair("game_desc",gameDesc));

   string response;
   if (httpClient.post(getRequestURL(),formFields,response,error))
   {
      vector<string> results;
      if (parseServerResponse(response,results,error))
      {
         result = true;
      }
   }

   return result;
}

bool Client::getActiveGames(vector<Game> & activeGames, std::string & error)
{
   bool result = false;
   error = "";
   activeGames.clear();

   vector< pair<string,string> > formFields;
   formFields.push_back(make_pair("method","getactivegames"));

   string response;
   if (httpClient.post(getRequestURL(),formFields,response,error))
   {
      vector<string> results;
      if (parseServerResponse(response,results,error))
      {
         result = true;

         while (results.size() >= 3)
         {
            Game g;
            g.game_name = results.front();
            results.erase(results.begin());
            g.game_ip = results.front();
            results.erase(results.begin());
            string utstr = results.front();
            results.erase(results.begin());
            istringstream ss(utstr);
            ss >> g.game_uptime;
            activeGames.push_back(g);
         }
      }
   }

   return result;
}

bool Client::parseServerResponse(string response, vector<string> & results, string & error)
{
   bool result = false;
   results.clear();
   error = "";
   string token;

   // split by line breaks
   istringstream ss(response);
   while (!ss.eof())
   {
      getline(ss,token,'\n');
      results.push_back(token);
   }
   results.erase(results.begin());

   // split off first line which indicates status
   string status = results.front();
   results.erase(results.begin());

   // check status line
   istringstream sss(status);
   getline(sss,token,':');
   if (token == "SUCCESS")
   {
      result = true;
   }
   else
   {
      getline(sss,error,':');
   }
  
   return result;
}

std::string Client::getRequestURL()
{
   stringstream str;

   str << "http://"
       << getSettingsString("gameserver_registry","host")
       << ":" << getSettingsInt("gameserver_registry","port")
       << getSettingsString("gameserver_registry","request_path");

   return str.str();
}
