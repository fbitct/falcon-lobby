// lpprotoDlg.h : header file
//

#pragma once
#include "afxwin.h"

#include "Client.h"
#include "Settings.h"

// ClpprotoDlg dialog
class ClpprotoDlg : public CDialog, public Settings
{
// Construction
public:
	ClpprotoDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	enum { IDD = IDD_LPPROTO_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

   CFont m_boldFont;

   Client m_client;

   bool setServerState(bool state);

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
   CEdit m_ctlName;
//   afx_msg void OnBnClickedButton1();
   afx_msg void OnBnClickedRegister();
   CEdit m_ctlToken;
   afx_msg void OnBnClickedUp();
   afx_msg void OnBnClickedDown();
   CStatic m_ctlTitlePublish;
   afx_msg void OnBnClickedFetchServers();
   CListBox m_ctlServerList;
   CStatic m_ctlTitleFetch;
   CButton m_ctlAutoDetect;
   afx_msg void OnBnClickedAutodetect();
   CButton m_ctlUp;
   CButton m_ctlDown;
   afx_msg void OnTimer(UINT nIDEvent);
   afx_msg void OnBnClickedViewStatus();
   afx_msg void OnBnClickedSubmitPublicInfo();
   CEdit m_ctlHomePage;
   CEdit m_ctlVoiceComms;
   CEdit m_ctlDesc;
};
