#ifndef SETTINGS_H
#define SETTINGS_H

class INIFile;

#include <string>

class Settings
{
public:
   Settings();
   virtual ~Settings();

   std::string getSettingsString(std::string section, std::string name);
   int getSettingsInt(std::string section, std::string name);

   void setSettingsString(std::string section, std::string name, std::string val);

private:
   INIFile * inifile;
};

#endif
