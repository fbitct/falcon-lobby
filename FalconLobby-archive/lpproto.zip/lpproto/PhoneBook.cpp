#include "stdafx.h"
#include "PhoneBook.h"

#include <string>
#include <sstream>
using namespace std;

typedef unsigned char uchar;
typedef unsigned long ulong;

#define PROTOCOL      0
#define LAN_RATE      1
#define INTERNET_RATE 0
#define JETNET_RATE   0
#define IP_ADDRESS    0
#define FLAG          1
#define COUNT         1

// received the record format info via Email from LP for the comHistory.dat file
// and then deduced the above constants from reading in the file on my machine
// which was setup with a couple internet servers; the file contains a 32-bit
// value which indicates the # of entries, followed by a record for each entry.
// the fields used for F4AF which need to be filled in are url (holds a string
// form of the server IP address), servername (friendly name), and password
// (server password)

// the key field is the url (IP address); if there are multiple entries in the
// phone book with the same url, only one of them will be displayed in Falcon

class PhoneBookRecord
{
public:
   //the below is commented out as I didn't have access to the referenced header
   //file and so just assumed it was a 32-bit enum
	//FalconConnectionTypes	protocol;	// Protocol comes from F4Comms.h - "FalconConnectionTypes"
   unsigned long protocol;
	uchar		lan_rate;
	uchar		internet_rate;
	uchar		jetnet_rate;
	ulong		ip_address;				// Use this or the phone_number below
	char		url[40];		// Save the URL here, was Phone number, in string form.
	char		servername[40];
	char		theatername[20];
	char		password[33];
	char		flag;
	char		count;	

   PhoneBookRecord()
   {
      memset(this,0,sizeof(PhoneBookRecord));
      protocol = PROTOCOL;
      lan_rate = LAN_RATE;
      internet_rate = INTERNET_RATE;
      jetnet_rate = JETNET_RATE;
      ip_address = IP_ADDRESS;
      flag = FLAG;
      count = COUNT;
   }

   string toString()
   {
      stringstream ss;
      ss << "PhoneBookRecord { "
         << "protocol=" << protocol
         << ", lan_rate=" << (ulong)lan_rate
         << ", internet_rate=" << (ulong)internet_rate
         << ", jetnet_rate=" << (ulong)jetnet_rate;
      struct in_addr ia;
      memcpy(&ia,&ip_address,sizeof(ip_address));
      ss << ", ip_address=" << inet_ntoa(ia)
         << ", url=\"" << url << "\""
         << ", servername=\"" << servername << "\""
         << ", theatername=\"" << theatername << "\""
         << ", password=\"" << password << "\""
         << ", flag=" << (ulong)flag
         << ", count=" << (ulong)count
         << " }";
      return ss.str();
   }
};

PhoneBook::PhoneBook()
{
}

bool PhoneBook::exists()
{
   string phoneBookFile;
   return getPhoneBookFile(phoneBookFile);
}

PhoneBook::~PhoneBook()
{
}

void PhoneBook::makeBackupCopy()
{
   string phoneBookFile;
   if (getPhoneBookFile(phoneBookFile))
   {
      string pbFileOrig = phoneBookFile;
      pbFileOrig = pbFileOrig + ".orig";
      CopyFile(phoneBookFile.c_str(),pbFileOrig.c_str(),FALSE);
   }
}

void PhoneBook::clear()
{
   string phoneBookFile;
   if (getPhoneBookFile(phoneBookFile))
   {
      // overwrite existing file with an empty one
      FILE * f = fopen(phoneBookFile.c_str(),"wb");
      if (f != NULL)
      {
         ulong numEntries = 0;
         fwrite(&numEntries,sizeof(numEntries),1,f);

         fflush(f);
         fclose(f);
      }
   }
}

void PhoneBook::addEntry(std::string game_name, std::string game_ip)
{
   string phoneBookFile;
   if (getPhoneBookFile(phoneBookFile))
   {
      FILE * f = fopen(phoneBookFile.c_str(),"r+b");
      if (f != NULL)
      {
         // read current # entries
         ulong numEntries = 0;
         fread(&numEntries,sizeof(numEntries),1,f);

         // append new entry
         fseek(f,sizeof(numEntries)+(sizeof(PhoneBookRecord)*numEntries),SEEK_SET);
         PhoneBookRecord pbr;
         strcpy(pbr.servername,game_name.c_str());
         strcpy(pbr.url,game_ip.c_str());
         fwrite(&pbr,sizeof(PhoneBookRecord),1,f);

         // update record count
         numEntries++;
         fseek(f,0,SEEK_SET);
         fwrite(&numEntries,sizeof(numEntries),1,f);

         fflush(f);
         fclose(f);
      }
   }
}

bool PhoneBook::getPhoneBookFile(std::string & phoneBookFile)
{
   bool result = false;
   phoneBookFile = "";

   // generate path to the phone book file using registry entries
   HKEY hKey;
   if (RegOpenKeyEx(HKEY_LOCAL_MACHINE,getSettingsString("Falcon","instdir_regkey").c_str(),0,KEY_READ,&hKey) == ERROR_SUCCESS)
   {
      const int maxpathlen = 4096;
      char pathbuf[maxpathlen+1];
      memset(pathbuf,0,maxpathlen+1);
      DWORD vType;
      DWORD bufSize = maxpathlen;

      if (RegQueryValueEx(hKey,getSettingsString("Falcon","instdir_regval").c_str(),0,&vType,(LPBYTE)pathbuf,&bufSize) == ERROR_SUCCESS)
      {
         stringstream ss;
         ss << pathbuf << getSettingsString("Falcon","phonebook_path");
         string pbfile = ss.str();

         // verify the file exists
         FILE * f = fopen(pbfile.c_str(),"rb");
         if (f != NULL)
         {
            result = true;
            phoneBookFile = pbfile;

            fclose(f);
         }
      }

      RegCloseKey(hKey);
   }

   return result;
}

