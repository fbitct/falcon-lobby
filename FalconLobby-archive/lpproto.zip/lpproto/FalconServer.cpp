#include "stdafx.h"
#include "FalconServer.h"

FalconServer::FalconServer()
{
}

FalconServer::~FalconServer()
{
}
