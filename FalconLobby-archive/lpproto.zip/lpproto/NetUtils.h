#ifndef NETUTILS_H
#define NETUTILS_H

class NetUtils
{
public:
	NetUtils();
	virtual ~NetUtils();

   bool portInUse(int port, int protocol);
};

#endif
