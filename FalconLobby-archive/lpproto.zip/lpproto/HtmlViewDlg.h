#pragma once


// CHtmlViewDlg dialog

class CHtmlViewDlg : public CDHtmlDialog
{
	DECLARE_DYNCREATE(CHtmlViewDlg)

public:
   CHtmlViewDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CHtmlViewDlg();
// Overrides
	HRESULT OnButtonOK(IHTMLElement *pElement);
	HRESULT OnButtonCancel(IHTMLElement *pElement);

// Dialog Data
	enum { IDD = IDD_HTMLVIEW, IDH = IDR_HTML_HTMLVIEWDLG };

   void setUrl(LPCTSTR url);

protected:
   CString m_url;

	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL OnInitDialog();

	DECLARE_MESSAGE_MAP()
	DECLARE_DHTML_EVENT_MAP()
};
