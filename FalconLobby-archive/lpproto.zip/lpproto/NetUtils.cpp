#include "stdafx.h"
#include "NetUtils.h"

NetUtils::NetUtils()
{
}

NetUtils::~NetUtils()
{
}

bool NetUtils::portInUse(int port, int protocol)
{
	bool result = false;

   // create socket
   SOCKET sock = socket(AF_INET,protocol,0);
	if (sock != INVALID_SOCKET)
	{
	   struct sockaddr_in addr;
	   memset(&addr,0,sizeof(addr));
         addr.sin_family = AF_INET;
         addr.sin_port = htons(port);
         addr.sin_addr.S_un.S_addr = INADDR_ANY;

      // attempt to bind to the specified port
		int berr = bind(sock,(sockaddr*)&addr,sizeof(addr));
		if (berr == SOCKET_ERROR)
		{
			DWORD lerr = GetLastError();
			if (lerr == WSAEADDRINUSE)
			{
            // bind failed, port was in use already
				result = true;
			}
		}

      // close the socket
		closesocket(sock);
	}

   return result;
}

